<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$route['messenger_bot_enhancers/messenger_checkbox_plugin.js'] = 'Messenger_bot_enhancers/messenger_checkbox_plugin';
$route['messenger_bot_enhancers/send_to_messenger_plugin.js'] = 'Messenger_bot_enhancers/send_to_messenger_plugin';
$route['messenger_bot_enhancers/mme_link.js'] = 'Messenger_bot_enhancers/mme_link';
